# To run this locally, install dependencies in your command prompt/terminal:
# pip install flask flask-cors yfinance pandas numpy tensorflow xgboost scikit-learn

from flask import Flask, jsonify
from flask_cors import CORS
import joblib
import numpy as np
import pandas as pd
import yfinance as yf
from tensorflow.keras.models import load_model
import xgboost as xgb

app = Flask(__name__)
CORS(app) # Enables CORS so your frontend website can safely make API requests

# Load the models and scalers globally when the app starts
lstm_model = load_model('lstm_forex_model.keras')
xgb_model = xgb.XGBRegressor()
xgb_model.load_model('xgb_forex_model.json')
scaler_x = joblib.load('feature_scaler.pkl')
scaler_y = joblib.load('target_scaler.pkl')

def calculate_rsi(series, window=14):
    delta = series.diff(1)
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.ewm(com=window - 1, min_periods=window).mean()
    avg_loss = loss.ewm(com=window - 1, min_periods=window).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


# Add this to app.py
@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "service": "forex_engine"}), 200

@app.route('/predict', methods=['GET'])
def get_forecast():
    try:
        ticker = "INR=X"
        df_live = yf.download(ticker, period="6mo", interval="1d")
        
        if isinstance(df_live.columns, pd.MultiIndex):
            df_live.columns = df_live.columns.get_level_values(0)
            
        df_live = df_live[['Close']].copy()
        df_live.columns = ['Price']
        df_live = df_live.dropna()
        
        df_live['Return'] = df_live['Price'].diff()
        df_live['RSI'] = calculate_rsi(df_live['Price'])
        df_live['SMA_20'] = df_live['Price'].rolling(window=20).mean()
        df_live['SMA_50'] = df_live['Price'].rolling(window=50).mean()
        df_live = df_live.dropna()
        
        feature_cols = ['Price', 'Return', 'RSI', 'SMA_20', 'SMA_50']
        look_back = 60
        
        # Prepare latest window sequence
        X_scaled_live = scaler_x.transform(df_live[feature_cols].values)
        current_sequence = X_scaled_live[-look_back:].copy()
        
        last_known_price = df_live['Price'].iloc[-1]
        forecast_steps = 20
        future_predictions = []
        
        for step in range(forecast_steps):
            seq_input = current_sequence.reshape(1, look_back, 5)
            lstm_pred_step = lstm_model.predict(seq_input, verbose=0)
            
            last_step_features = seq_input[:, -1, :]
            xgb_input = np.hstack([last_step_features, lstm_pred_step])
            
            pred_scaled_ret = xgb_model.predict(xgb_input)
            pred_real_ret = scaler_y.inverse_transform(pred_scaled_ret.reshape(-1, 1))[0][0]
            
            projected_price = last_known_price + pred_real_ret
            future_predictions.append(float(projected_price))
            
            # Dynamic technical features reconstruction for simulated timeline
            historical_prices_with_new = list(df_live['Price'].iloc[-120:].values) + future_predictions
            new_prices_series = pd.Series(historical_prices_with_new)
            
            delta = new_prices_series.diff(1)
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.ewm(com=13, min_periods=14).mean()
            avg_loss = loss.ewm(com=13, min_periods=14).mean()
            rs = avg_gain / avg_loss
            new_rsi = (100 - (100 / (1 + rs))).iloc[-1]
            if np.isnan(new_rsi):
                new_rsi = 50.0
                
            new_sma20 = new_prices_series.rolling(window=20).mean().iloc[-1]
            new_sma50 = new_prices_series.rolling(window=50).mean().iloc[-1]
            
            raw_feature_vector = np.array([[projected_price, pred_real_ret, new_rsi, new_sma20, new_sma50]])
            scaled_feature_vector = scaler_x.transform(raw_feature_vector)
            
            current_sequence = np.vstack([current_sequence[1:], scaled_feature_vector[0]])
            last_known_price = projected_price
            
        forecast_dates = pd.date_range(start=df_live.index[-1] + pd.Timedelta(days=1), periods=forecast_steps, freq='B')
        forecast_list = [
            {"date": date.strftime('%Y-%m-%d'), "predicted_price": round(price, 4)}
            for date, price in zip(forecast_dates, future_predictions)
        ]
        
        return jsonify({
            "status": "success",
            "currency_pair": ticker,
            "current_price": round(float(df_live['Price'].iloc[-1]), 4),
            "forecast": forecast_list
        })
        
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
