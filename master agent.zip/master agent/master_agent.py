import subprocess
import time
import requests
import sys
import os

# 1. Define your microservices and their exact folder paths
services = {
    "Forex Engine": {
        "file": "forex_app.py", 
        "port": 5000, 
        "folder_path": "forex_service",  # Name of your forex folder
        "process": None
    },
    "Route Engine": {
        "file": "route_app.py", 
        "port": 5001, 
        "folder_path": "route_service",  # Name of your route folder
        "process": None
    }
}

def start_service(name, info):
    print(f"🤖 Agent: Initiating {name} from /{info['folder_path']} on port {info['port']}...")
    
    # Get the absolute path to the folder
    target_directory = os.path.abspath(info["folder_path"])
    
    # Launch the app. The 'cwd' argument tells Python to run the script 
    # FROM INSIDE that specific folder, so it can find its downloaded models.
    process = subprocess.Popen([sys.executable, info["file"]], cwd=target_directory)
    return process

def monitor_services():
    while True:
        for name, info in services.items():
            url = f"http://127.0.0.1:{info['port']}/health"
            process = info["process"]
            
            try:
                response = requests.get(url, timeout=3)
                if response.status_code == 200:
                    print(f"   ✅ {name}: Online and healthy.")
            except requests.exceptions.RequestException:
                print(f"   🚨 {name}: Unresponsive!")
                
                if process.poll() is not None:
                    print(f"   🔄 Restarting {name}...")
                    services[name]["process"] = start_service(name, info)
                    
        print("-" * 40)
        time.sleep(10)

if __name__ == "__main__":
    print("🛡️ Master Management Agent Started\n" + "="*40)
    
    for name, info in services.items():
        services[name]["process"] = start_service(name, info)
        
    time.sleep(5) 
    print("="*40)
    
    try:
        monitor_services()
    except KeyboardInterrupt:
        print("\n🛑 Agent shutting down. Terminating all servers...")
        for name, info in services.items():
            if info["process"]:
                info["process"].terminate()